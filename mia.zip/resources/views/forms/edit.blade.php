<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Edit Form - {{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
        }
    </script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <style>
        .field-row {
            transition: background-color 0.2s;
        }

        .field-row:hover {
            background-color: rgba(59, 130, 246, 0.05);
        }

        input[type="number"],
        textarea {
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        input[type="number"]:focus,
        textarea:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .error-highlight {
            border-color: #ef4444 !important;
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1) !important;
        }

        /* Hide number input spinners */
        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type="number"] {
            -moz-appearance: textfield;
        }

        /* Animation for slide-in messages */
        @keyframes slide-in {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-slide-in {
            animation: slide-in 0.3s ease-out;
        }

        /* Group By Autocomplete Styles */
        #groupByAutocomplete {
            max-height: 240px;
        }

        #groupByAutocomplete .group-by-suggestion {
            transition: background-color 0.15s ease-in-out;
        }

        #groupByAutocomplete .group-by-suggestion:hover,
        #groupByAutocomplete .group-by-suggestion.active {
            background-color: #f3f4f6;
        }

        .dark #groupByAutocomplete .group-by-suggestion:hover,
        .dark #groupByAutocomplete .group-by-suggestion.active {
            background-color: #374151;
        }
    </style>
</head>

<body class="bg-gray-50 dark:bg-gray-900">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div class="flex items-center justify-between">
                    <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">Edit Form</h1>
                    <div class="flex items-center space-x-3">
                        <a href="{{ route('forms.index') }}"
                            class="inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                            </svg>
                            Back to List
                        </a>
                        <x-user-dropdown />
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
            <!-- Success Message -->
            @if (session('success'))
                <div
                    class="mb-6 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-l-4 border-green-500 text-green-800 dark:text-green-200 px-5 py-4 rounded-r-lg shadow-md animate-slide-in">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="font-medium">{{ session('success') }}</span>
                    </div>
                </div>
            @endif

            <!-- Error Message -->
            @if (session('error'))
                <div
                    class="mb-6 bg-gradient-to-r from-red-50 to-rose-50 dark:from-red-900/20 dark:to-rose-900/20 border-l-4 border-red-500 text-red-800 dark:text-red-200 px-5 py-4 rounded-r-lg shadow-md animate-slide-in">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="font-medium">{{ session('error') }}</span>
                    </div>
                </div>
            @endif

            @if ($errors->any())
                <div
                    class="mb-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200 px-4 py-3 rounded-lg">
                    <ul class="list-disc list-inside">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="flex gap-6">
                <!-- Sidebar -->
                <aside class="w-80 flex-shrink-0">
                    <div
                        class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 sticky top-4">
                        <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4 text-center">
                            Related Items
                        </h2>

                        <!-- Add Item and Export Buttons -->
                        <div class="mb-4 flex gap-2">
                            <button type="button" id="addItemBtn"
                                class="w-1/2 inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 4v16m8-8H4"></path>
                                </svg>
                                Add Item
                            </button>
                            <a type="button" id="exportBtn"
                                href="{{ route('forms.export-by-project', ['client_name' => $form->client_name, 'project_name' => $form->project_name]) }}"
                                class="w-1/2 inline-flex items-center justify-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                                    </path>
                                </svg>
                                Export
                            </a>
                        </div>

                        <div id="sidebarItemsList" class="space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto">
                            @if ($relatedForms->count() > 0)
                                @foreach ($relatedForms as $relatedForm)
                                    <div class="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors sidebar-item"
                                        data-form-id="{{ $relatedForm->id }}">
                                        <div class="flex items-start justify-between">
                                            <div class="flex-1 cursor-pointer"
                                                onclick="loadFormFields({{ $relatedForm->id }})">
                                                <p class="text-sm font-medium text-gray-900 dark:text-white">
                                                    {{ $relatedForm->item_name ?: 'No Item Name' }}
                                                </p>
                                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                                    Created: {{ $relatedForm->created_at->format('M d, Y') }}
                                                </p>
                                            </div>
                                            <button type="button"
                                                onclick="event.stopPropagation(); confirmDeleteItem({{ $relatedForm->id }}, '{{ addslashes($relatedForm->item_name ?: 'No Item Name') }}')"
                                                class="ml-2 p-1.5 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
                                                title="Delete item">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                                    </path>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <div id="emptySidebarMessage" class="text-center py-8">
                                    <p class="text-sm text-gray-500 dark:text-gray-400">
                                        No items found.
                                    </p>
                                </div>
                            @endif
                        </div>
                    </div>
                </aside>

                <!-- Main Content Area -->
                <div class="flex-1">
                    <form action="{{ route('forms.store') }}" method="POST" id="formForm">
                        @csrf
                        <input type="hidden" name="item_name" id="item_name_input" value="">
                        <input type="hidden" name="is_new_item" id="is_new_item" value="0">

                        <!-- Form Details -->
                        <div
                            class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-6">
                            <div class="flex items-center justify-between mb-4">
                                <h2 class="text-lg font-semibold text-gray-900 dark:text-white">Form Details</h2>
                                <button type="button" id="updateFormDetailsBtn"
                                    class="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15">
                                        </path>
                                    </svg>
                                    Update Form
                                </button>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="client_name"
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        Client Name <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" id="client_name" name="client_name"
                                        value="{{ old('client_name', $form->client_name) }}" required
                                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                                </div>
                                <div>
                                    <label for="project_name"
                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        Project Name <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" id="project_name" name="project_name"
                                        value="{{ old('project_name', $form->project_name) }}" required
                                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                                </div>
                            </div>
                        </div>

                        <!-- Message Section -->
                        <div id="messageSection"
                            class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-6 mb-6">
                            <div class="flex items-start">
                                <svg class="w-6 h-6 text-blue-600 dark:text-blue-400 mr-3 mt-0.5 flex-shrink-0"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <div>
                                    <h3 class="text-sm font-semibold text-blue-900 dark:text-blue-200 mb-1">
                                        Select an Item to Edit
                                    </h3>
                                    <p class="text-sm text-blue-800 dark:text-blue-300">
                                        Please select an item from the sidebar to edit it, or click on the <strong>"Add
                                            Item"</strong> button in the sidebar to create a new item.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Fields Section (will be populated via AJAX) -->
                        <div id="fieldsSection" class="hidden">
                            <div
                                class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                                <div class="mb-4">
                                    <h2 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Fields</h2>

                                    <!-- Item Name and Unit Fields -->
                                    <div id="itemNameField" class="mb-6">
                                        <div class="grid grid-cols-3 gap-4 mb-4">
                                            <div>
                                                <label for="fields_item_name"
                                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                    Item Name
                                                </label>
                                                <input type="text" id="fields_item_name" name="fields_item_name"
                                                    placeholder="Enter item name"
                                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                                            </div>
                                            <div>
                                                <label for="fields_unit"
                                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                    Unit
                                                </label>
                                                <select id="fields_unit" name="fields_unit"
                                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                                                    <option value="">Select Unit</option>
                                                    @foreach(unit_types() as $unit)
                                                    <option value="{{ $unit }}">{{ $unit }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div>
                                                <label for="fields_rate"
                                                    class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                    Rate
                                                </label>
                                                <input type="number" id="fields_rate" name="fields_rate"
                                                    step="0.01" min="0" placeholder="Enter rate"
                                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                                            </div>
                                        </div>
                                        <div class="w-full">
                                            <label for="fields_group_by"
                                                class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Group By
                                            </label>
                                            <div class="relative">
                                                <input type="text" id="fields_group_by" name="fields_group_by"
                                                    placeholder="Enter group by" autocomplete="off"
                                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                                                <div id="groupByAutocomplete"
                                                    class="hidden absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                                                    <!-- Autocomplete suggestions will be inserted here -->
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Duplicate Section (only shown in Add Item mode) -->
                                        <div id="duplicateSection"
                                            class="hidden mt-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600">
                                            <div class="flex items-center mb-3">
                                                <input type="checkbox" id="duplicateCheckbox"
                                                    class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                                <label for="duplicateCheckbox"
                                                    class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                                                    Duplicate from existing item
                                                </label>
                                            </div>
                                            <div id="duplicateDropdownContainer" class="hidden">
                                                <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                                                    <div class="md:col-span-2">
                                                        <label for="duplicateItemSelect"
                                                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                            Select Item to Duplicate
                                                        </label>
                                                        <select id="duplicateItemSelect"
                                                            class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                                                            <option value="">-- Select an item --</option>
                                                        </select>
                                                    </div>
                                                    <div class="flex items-end">
                                                        <button type="button" id="duplicateButton"
                                                            class="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
                                                            disabled>
                                                            Duplicate
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Fields Table -->
                                <div class="overflow-x-auto">
                                    <table class="w-full">
                                        <thead>
                                            <tr class="bg-gray-100 dark:bg-gray-700">
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider w-12">
                                                    #</th>
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider min-w-[300px]">
                                                    Description</th>
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider w-32">
                                                    Number</th>
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider w-32">
                                                    Length</th>
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider w-32">
                                                    Width</th>
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider w-32">
                                                    Height</th>
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider w-32 whitespace-nowrap">
                                                    T QTY</th>
                                                <th
                                                    class="px-4 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider w-20">
                                                    Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="fieldsTableBody">
                                            <!-- Fields will be populated here via AJAX -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </main>

        <!-- Duplicate Group Modal -->
        <div id="duplicateGroupModal"
            class="fixed inset-0 bg-black/50 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
            <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full transform transition-all">
                <div class="p-6">
                    <div class="flex items-center mb-4">
                        <div
                            class="flex-shrink-0 w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                            </svg>
                        </div>
                        <h3 class="ml-4 text-xl font-bold text-gray-900 dark:text-white">Duplicate Group</h3>
                    </div>
                    <p class="text-gray-600 dark:text-gray-300 mb-4">
                        Enter a new name for the duplicated group. All items in the group will be duplicated with the same item names.
                    </p>
                    <div class="mb-4">
                        <label for="newGroupNameInput"
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Original Group Name
                        </label>
                        <input type="text" id="originalGroupNameDisplay" readonly
                            class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 cursor-not-allowed">
                    </div>
                    <div class="mb-6">
                        <label for="newGroupNameInput"
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            New Group Name <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="newGroupNameInput" 
                            placeholder="Enter new group name"
                            class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white">
                    </div>
                    <div class="flex justify-end space-x-3">
                        <button id="cancelDuplicateGroup"
                            class="px-5 py-2.5 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium">
                            Cancel
                        </button>
                        <button id="confirmDuplicateGroup"
                            class="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:from-indigo-700 hover:to-indigo-800 transition-all font-medium shadow-lg">
                            Duplicate
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Delete Item Confirmation Modal -->
        <div id="deleteItemModal"
            class="fixed inset-0 bg-black/50 backdrop-blur-sm hidden items-center justify-center z-50 p-4">
            <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full transform transition-all">
                <div class="p-6">
                    <div class="flex items-center mb-4">
                        <div
                            class="flex-shrink-0 w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-red-600 dark:text-red-400" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z">
                                </path>
                            </svg>
                        </div>
                        <h3 class="ml-4 text-xl font-bold text-gray-900 dark:text-white">Confirm Delete</h3>
                    </div>
                    <p class="text-gray-600 dark:text-gray-300 mb-6" id="deleteItemModalMessage">
                        Are you sure you want to delete this item? This action cannot be undone and all associated
                        fields will be deleted.
                    </p>
                    <div class="flex justify-end space-x-3">
                        <button id="cancelDeleteItem"
                            class="px-5 py-2.5 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium">
                            Cancel
                        </button>
                        <button id="confirmDeleteItem"
                            class="px-5 py-2.5 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg hover:from-red-700 hover:to-red-800 transition-all font-medium shadow-lg">
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Fixed Form Actions -->
        <div
            class="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg z-50">
            <div class="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div class="flex items-center justify-center space-x-4">
                    <a href="{{ route('forms.index') }}"
                        class="px-6 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        Cancel
                    </a>
                    <button type="button" onclick="addFieldRow()" id="addRowBtn"
                        class="hidden inline-flex items-center px-6 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4">
                            </path>
                        </svg>
                        Add Row
                    </button>
                    <button type="submit" form="formForm" id="updateFormBtn"
                        class="hidden px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200">
                        Update Form
                    </button>
                    <div id="exportDropdown" class="hidden relative inline-block text-left">
                        <button type="button" id="exportDropdownBtn"
                            class="inline-flex items-center px-6 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg shadow-sm transition-colors duration-200"
                            onclick="toggleExportMenu()">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                                </path>
                            </svg>
                            Export
                            <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </button>
                        <div id="exportDropdownMenu"
                            class="hidden absolute right-0 bottom-full mb-2 w-56 rounded-md shadow-lg bg-white dark:bg-gray-800 ring-1 ring-black ring-opacity-5 z-50">
                            <div class="py-1">
                                <a href="#" id="exportAsGroupBtn"
                                    class="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                                    onclick="closeExportMenu()">
                                    Export as Group
                                </a>
                                <a href="#" id="exportAsItemBtn"
                                    class="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                                    onclick="closeExportMenu()">
                                    Export as Item
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let fieldIndex = 30;
        let currentFormId = null;

        // Handle sidebar item clicks
        $(document).ready(function() {
            // Refresh sidebar on page load to show grouped items
            refreshSidebar();
            // Delegate click handler for sidebar items (works for dynamically added items)
            // Note: Click handling is now done via onclick in the item div to allow delete button clicks

            // Handle Add Item button click
            $('#addItemBtn').on('click', function() {
                loadEmptyFieldsForm();
            });

            // Handle duplicate checkbox change
            $('#duplicateCheckbox').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#duplicateDropdownContainer').removeClass('hidden');
                    loadSidebarItemsForDuplicate();
                } else {
                    $('#duplicateDropdownContainer').addClass('hidden');
                    $('#duplicateItemSelect').val('');
                    $('#duplicateButton').prop('disabled', true);
                }
            });

            // Handle duplicate item select change
            $('#duplicateItemSelect').on('change', function() {
                const selectedValue = $(this).val();
                $('#duplicateButton').prop('disabled', !selectedValue);
            });

            // Handle duplicate button click
            $('#duplicateButton').on('click', function() {
                const selectedFormId = $('#duplicateItemSelect').val();
                if (selectedFormId) {
                    duplicateItemFields(selectedFormId);
                }
            });

            // Handle form submission
            $('#formForm').on('submit', function(e) {
                e.preventDefault();
                submitForm();
            });

            // Handle update form details button click
            $('#updateFormDetailsBtn').on('click', function() {
                updateFormDetails();
            });

            // Initialize group_by autocomplete
            initializeGroupByAutocomplete();
        });

        // Export dropdown helpers (bottom navbar)
        function toggleExportMenu() {
            const menu = document.getElementById('exportDropdownMenu');
            if (!menu) return;
            menu.classList.toggle('hidden');
        }

        function closeExportMenu() {
            const menu = document.getElementById('exportDropdownMenu');
            if (!menu) return;
            menu.classList.add('hidden');
        }

        // Close export menu on outside click
        document.addEventListener('click', function(e) {
            const dropdown = document.getElementById('exportDropdown');
            const menu = document.getElementById('exportDropdownMenu');
            if (!dropdown || !menu) return;
            if (!dropdown.contains(e.target)) {
                menu.classList.add('hidden');
            }
        });

        function toggleGroup(groupId) {
            const $groupItems = $('#' + groupId);
            const $groupHeader = $('[data-group-id="' + groupId + '"]');
            const $arrow = $groupHeader.find('.group-arrow');

            if ($groupItems.hasClass('hidden')) {
                $groupItems.removeClass('hidden');
                $arrow.css('transform', 'rotate(90deg)');
            } else {
                $groupItems.addClass('hidden');
                $arrow.css('transform', 'rotate(0deg)');
            }
        }

        function initializeGroupByAutocomplete() {
            let autocompleteTimeout;
            const $input = $('#fields_group_by');
            const $autocomplete = $('#groupByAutocomplete');

            $input.on('input', function() {
                const query = $(this).val().trim();

                // Clear previous timeout
                clearTimeout(autocompleteTimeout);

                // Hide autocomplete if input is empty
                if (query.length === 0) {
                    $autocomplete.addClass('hidden').empty();
                    return;
                }

                // Debounce the AJAX call
                autocompleteTimeout = setTimeout(function() {
                    $.ajax({
                        url: '{{ route('api.group-by-values') }}',
                        method: 'GET',
                        data: {
                            q: query
                        },
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                            'Accept': 'application/json'
                        },
                        success: function(suggestions) {
                            if (suggestions.length === 0) {
                                $autocomplete.addClass('hidden').empty();
                                return;
                            }

                            let html = '';
                            suggestions.forEach(function(item) {
                                html += `
                                    <div class="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer group-by-suggestion" data-value="${item.value.replace(/"/g, '&quot;')}">
                                        ${item.label}
                                    </div>
                                `;
                            });

                            $autocomplete.html(html).removeClass('hidden');

                            // Handle suggestion click
                            $autocomplete.find('.group-by-suggestion').on('click', function() {
                                const value = $(this).data('value');
                                $input.val(value);
                                $autocomplete.addClass('hidden').empty();
                            });
                        },
                        error: function() {
                            $autocomplete.addClass('hidden').empty();
                        }
                    });
                }, 300); // 300ms debounce
            });

            // Hide autocomplete when clicking outside
            $(document).on('click', function(e) {
                if (!$(e.target).closest('#fields_group_by, #groupByAutocomplete').length) {
                    $autocomplete.addClass('hidden');
                }
            });

            // Handle keyboard navigation
            $input.on('keydown', function(e) {
                const $suggestions = $autocomplete.find('.group-by-suggestion');
                const $active = $autocomplete.find('.group-by-suggestion.active');

                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    if ($active.length) {
                        $active.removeClass('active');
                        $active.next().addClass('active bg-gray-100 dark:bg-gray-700');
                    } else {
                        $suggestions.first().addClass('active bg-gray-100 dark:bg-gray-700');
                    }
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    if ($active.length) {
                        $active.removeClass('active');
                        $active.prev().addClass('active bg-gray-100 dark:bg-gray-700');
                    } else {
                        $suggestions.last().addClass('active bg-gray-100 dark:bg-gray-700');
                    }
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    if ($active.length) {
                        const value = $active.data('value');
                        $input.val(value);
                        $autocomplete.addClass('hidden').empty();
                    }
                } else if (e.key === 'Escape') {
                    $autocomplete.addClass('hidden').empty();
                }
            });
        }

        function loadFormFields(formId) {
            currentFormId = formId;

            // Update active state
            $('.sidebar-item').removeClass(
                'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700');
            $('.sidebar-item').addClass('bg-gray-50 dark:bg-gray-700');
            $(`.sidebar-item[data-form-id="${formId}"]`).removeClass('bg-gray-50 dark:bg-gray-700');
            $(`.sidebar-item[data-form-id="${formId}"]`).addClass(
                'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700');

            // Show loading state
            $('#fieldsSection').addClass('hidden');
            $('#messageSection').html(`
                <div class="flex items-center justify-center py-8">
                    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    <span class="ml-3 text-blue-600 dark:text-blue-400">Loading fields...</span>
                </div>
            `);

            $.ajax({
                url: `/api/forms/${formId}/fields`,
                method: 'GET',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    renderFieldsTable(response);
                    $('#messageSection').addClass('hidden');
                    $('#fieldsSection').removeClass('hidden');

                    // Show action buttons
                    $('#addRowBtn').removeClass('hidden');
                    $('#updateFormBtn').removeClass('hidden');
                    $('#updateFormBtn').text('Update Form');
                    // Show export dropdown and set export links
                    $('#exportDropdown').removeClass('hidden');
                    $('#exportAsItemBtn').attr('href', `/forms/${formId}/export`);
                    const clientName = encodeURIComponent($('#client_name').val() || '');
                    const projectName = encodeURIComponent($('#project_name').val() || '');
                    if (response.group_by && response.group_by.trim() !== '') {
                        const groupBy = encodeURIComponent(response.group_by);
                        $('#exportAsGroupBtn')
                            .removeClass('pointer-events-none opacity-50')
                            .attr('href',
                                `{{ url('forms/project/export-group') }}?client_name=${clientName}&project_name=${projectName}&group_by=${groupBy}`
                                );
                    } else {
                        // Disable group export if no group_by present on selected item
                        $('#exportAsGroupBtn')
                            .addClass('pointer-events-none opacity-50')
                            .attr('href', '#');
                    }

                    // Show and populate item name, unit, rate, and group_by fields for existing items
                    $('#itemNameField').removeClass('hidden');
                    $('#fields_item_name').val(response.item_name || '');
                    $('#fields_unit').val(response.unit || '');
                    $('#fields_rate').val(response.rate || '');
                    $('#fields_group_by').val(response.group_by || '');

                    // Hide duplicate section when editing existing item
                    $('#duplicateSection').addClass('hidden');

                    // Update form for editing
                    $('#formForm').attr('action', `/forms/${formId}`);
                    $('#formForm').find('input[name="_method"]').remove();
                    $('#formForm').append('<input type="hidden" name="_method" value="PUT">');
                    $('#item_name_input').val(response.item_name || '');
                    $('#is_new_item').val('0');
                    currentFormId = formId;
                },
                error: function(xhr) {
                    $('#messageSection').html(`
                        <div class="flex items-start">
                            <svg class="w-6 h-6 text-red-600 dark:text-red-400 mr-3 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <div>
                                <h3 class="text-sm font-semibold text-red-900 dark:text-red-200 mb-1">
                                    Error Loading Fields
                                </h3>
                                <p class="text-sm text-red-800 dark:text-red-300">
                                    Failed to load fields. Please try again.
                                </p>
                            </div>
                        </div>
                    `);
                    $('#fieldsSection').addClass('hidden');
                }
            });
        }

        function renderFieldsTable(data) {
            const tbody = $('#fieldsTableBody');
            tbody.empty();

            data.fields.forEach(function(field, index) {
                const rowNum = index + 1;
                const row = `
                    <tr class="field-row border-b border-gray-200 dark:border-gray-700">
                        <td class="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">${rowNum}</td>
                        <td class="px-4 py-3">
                            ${field.id ? `<input type="hidden" name="fields[${index}][id]" value="${field.id}">` : ''}
                            <textarea name="fields[${index}][description]" 
                                      rows="1"
                                      placeholder="Enter description"
                                      oninput="calculateProduct(this)"
                                      class="field-description w-full min-w-[300px] px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white resize-none">${field.description || ''}</textarea>
                        </td>
                        <td class="px-4 py-3">
                            <input type="number" 
                                   name="fields[${index}][quantity]" 
                                   step="1" 
                                   placeholder="0"
                                   oninput="calculateProduct(this)"
                                   value="${field.quantity || ''}"
                                   class="field-quantity w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                        </td>
                        <td class="px-4 py-3">
                            <input type="number" 
                                   name="fields[${index}][length]" 
                                   step="0.01" 
                                   min="0"
                                   placeholder="0"
                                   oninput="calculateProduct(this)"
                                   value="${field.length || ''}"
                                   class="field-length w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                        </td>
                        <td class="px-4 py-3">
                            <input type="number" 
                                   name="fields[${index}][width]" 
                                   step="0.01" 
                                   min="0"
                                   placeholder="0"
                                   oninput="calculateProduct(this)"
                                   value="${field.width || ''}"
                                   class="field-width w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                        </td>
                        <td class="px-4 py-3">
                            <input type="number" 
                                   name="fields[${index}][height]" 
                                   step="0.01" 
                                   min="0"
                                   placeholder="0"
                                   oninput="calculateProduct(this)"
                                   value="${field.height || ''}"
                                   class="field-height w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                        </td>
                        <td class="px-4 py-3">
                            <input type="number" 
                                   name="fields[${index}][product]" 
                                   step="0.01"
                                   placeholder="0"
                                   readonly
                                   value="${field.product || ''}"
                                   class="field-product w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-600 text-gray-700 dark:text-gray-300 cursor-not-allowed">
                        </td>
                        <td class="px-4 py-3">
                            <button type="button" 
                                    onclick="removeFieldRow(this)" 
                                    class="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                </svg>
                            </button>
                        </td>
                    </tr>
                `;
                tbody.append(row);
            });

            // Recalculate products for existing values
            tbody.find('.field-quantity, .field-length, .field-width, .field-height').each(function() {
                if ($(this).val()) {
                    calculateProduct(this);
                }
            });
        }

        function calculateProduct(input) {
            const row = input.closest('tr');
            const quantity = parseFloat(row.querySelector('.field-quantity').value) || 1;
            const length = parseFloat(row.querySelector('.field-length').value) || 1;
            const width = parseFloat(row.querySelector('.field-width').value) || 1;
            const height = parseFloat(row.querySelector('.field-height').value) || 1;
            const productInput = row.querySelector('.field-product');

            // Calculate product if length, width, and height are greater than 0 (quantity can be negative)
            if (length > 0 && width > 0 && height > 0 && quantity !== 0) {
                const product = quantity * length * width * height;
                // Show original product value with up to 2 decimal places
                productInput.value = product.toFixed(2);
            } else {
                productInput.value = '';
            }
        }

        function loadEmptyFieldsForm() {
            currentFormId = null;

            // Reset form for new item
            $('#formForm').attr('action', '{{ route('forms.store') }}');
            $('#formForm').find('input[name="_method"]').remove();
            $('#item_name_input').val('');
            $('#is_new_item').val('1');

            // Show item name, unit, rate, and group_by fields for new items
            $('#itemNameField').removeClass('hidden');
            $('#fields_item_name').val('');
            $('#fields_unit').val('');
            $('#fields_rate').val('');
            $('#fields_group_by').val('');

            // Show duplicate section for new items
            $('#duplicateSection').removeClass('hidden');
            $('#duplicateCheckbox').prop('checked', false);
            $('#duplicateDropdownContainer').addClass('hidden');
            $('#duplicateItemSelect').val('');
            $('#duplicateButton').prop('disabled', true);

            // Generate 30 empty rows
            const emptyFields = [];
            for (let i = 0; i < 30; i++) {
                emptyFields.push({
                    id: null,
                    index: i,
                    description: '',
                    quantity: '',
                    length: '',
                    width: '',
                    height: '',
                    product: ''
                });
            }

            const emptyData = {
                form_id: null,
                item_name: '',
                fields: emptyFields
            };

            renderFieldsTable(emptyData);
            $('#messageSection').addClass('hidden');
            $('#fieldsSection').removeClass('hidden');
            $('#addRowBtn').removeClass('hidden');
            $('#updateFormBtn').removeClass('hidden');
            $('#updateFormBtn').text('Create Form');
            $('#exportDropdown').addClass('hidden');

            // Clear active state from sidebar items
            $('.sidebar-item').removeClass('bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700');
            $('.sidebar-item').addClass('bg-gray-50 dark:bg-gray-700');
        }

        function submitForm() {
            const isNewItem = $('#is_new_item').val() === '1';
            const url = isNewItem ? '{{ route('forms.store') }}' : $('#formForm').attr('action');

            // Show loading state
            const submitBtn = $('#updateFormBtn');
            const originalText = submitBtn.text();
            submitBtn.prop('disabled', true).text('Saving...');

            // Collect form data
            const formData = new FormData();
            formData.append('client_name', $('#client_name').val());
            formData.append('project_name', $('#project_name').val());

            // Get item name, unit, rate, and group_by from the visible fields (works for both new and existing items)
            const itemName = $('#fields_item_name').val();
            const unit = $('#fields_unit').val();
            const rate = $('#fields_rate').val();
            const groupBy = $('#fields_group_by').val();
            formData.append('item_name', itemName);
            formData.append('unit', unit);
            formData.append('rate', rate);
            formData.append('group_by', groupBy);

            // Collect fields data
            $('#fieldsTableBody tr').each(function(index) {
                const row = $(this);
                const description = row.find('.field-description').val() || '';
                const quantity = row.find('.field-quantity').val() || '';
                const length = row.find('.field-length').val() || '';
                const width = row.find('.field-width').val() || '';
                const height = row.find('.field-height').val() || '';
                const product = row.find('.field-product').val() || '';
                const fieldId = row.find('input[name*="[id]"]').val();

                // Only include fields with data
                if (description || quantity || length || width || height || product) {
                    if (fieldId) {
                        formData.append(`fields[${index}][id]`, fieldId);
                    }
                    formData.append(`fields[${index}][description]`, description);
                    formData.append(`fields[${index}][quantity]`, quantity);
                    formData.append(`fields[${index}][length]`, length);
                    formData.append(`fields[${index}][width]`, width);
                    formData.append(`fields[${index}][height]`, height);
                    formData.append(`fields[${index}][product]`, product);
                }
            });

            if (!isNewItem) {
                formData.append('_method', 'PUT');
            }

            $.ajax({
                url: url,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                success: function(response) {
                    submitBtn.prop('disabled', false).text(originalText);

                    if (isNewItem) {
                        // Refresh sidebar to include new item
                        refreshSidebar();
                        // Load the newly created form
                        loadFormFields(response.id);
                        // Show success message
                        showSuccessMessage('Item created successfully!');
                    } else {
                        // Refresh sidebar to show updated item name
                        refreshSidebar(currentFormId);
                        // Show success message
                        showSuccessMessage(response.message || 'Form updated successfully!');
                    }
                },
                error: function(xhr) {
                    submitBtn.prop('disabled', false).text(originalText);
                    let errorMessage = 'An error occurred. Please try again.';

                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                        const errors = Object.values(xhr.responseJSON.errors).flat();
                        errorMessage = errors.join('\\n');
                    } else if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error;
                    }

                    alert(errorMessage);
                }
            });
        }

        function refreshSidebar(selectedFormId = null) {
            const clientName = $('#client_name').val();
            const projectName = $('#project_name').val();

            if (!clientName || !projectName) {
                return;
            }

            $.ajax({
                    url: '{{ route('api.sidebar-items') }}',
                    method: 'GET',
                    data: {
                        client_name: clientName,
                        project_name: projectName
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                        'Accept': 'application/json'
                    },
                    success: function(items) {
                        const sidebarList = $('#sidebarItemsList');
                        sidebarList.empty();

                        if (items.length === 0) {
                            sidebarList.html(
                                '<div id="emptySidebarMessage" class="text-center py-8"><p class="text-sm text-gray-500 dark:text-gray-400">No items found.</p></div>'
                            );
                            return;
                        }

                        items.forEach(function(item) {
                                if (item.is_group) {
                                    // Render group header with expandable items
                                    const groupId = 'group-' + item.group_by.replace(/[^a-zA-Z0-9]/g, '-');
                                    const groupHtml = `
                                <div class="mb-2">
                                    <div class="flex items-center justify-between p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg border border-indigo-200 dark:border-indigo-700 group-header"
                                         data-group-id="${groupId}">
                                        <div class="flex items-center flex-1 cursor-pointer" onclick="toggleGroup('${groupId}')">
                                            <svg class="w-4 h-4 mr-2 text-indigo-600 dark:text-indigo-400 group-arrow transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                            </svg>
                                            <span class="text-sm font-semibold text-indigo-700 dark:text-indigo-300">${item.group_by}</span>
                                            <span class="ml-2 text-xs text-indigo-600 dark:text-indigo-400">(${item.items.length})</span>
                                        </div>
                                        <button type="button" 
                                            onclick="event.stopPropagation(); confirmDuplicateGroup('${item.group_by.replace(/'/g, "\\'")}')"
                                            class="ml-2 p-1.5 text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded transition-colors"
                                            title="Duplicate group">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                                            </svg>
                                        </button>
                                    </div>
                                    <div id="${groupId}" class="hidden mt-1 ml-4 space-y-2 group-items">
                                        ${item.items.map(function(subItem) {
                                            const itemName = subItem.item_name || 'No Item Name';
                                            const createdAt = new Date(subItem.created_at).toLocaleDateString('en-US', {
                                                month: 'short',
                                                day: 'numeric',
                                                year: 'numeric'
                                            });
                                            const isSelected = selectedFormId && subItem.id == selectedFormId;
                                            const bgClass = isSelected ?
                                                'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700' :
                                                'bg-gray-50 dark:bg-gray-700';
                                            
                                            return `
                                                <div class="p-2 ${bgClass} rounded-lg border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors sidebar-item"
                                                     data-form-id="${subItem.id}">
                                                    <div class="flex items-start justify-between">
                                                        <div class="flex-1 cursor-pointer" onclick="loadFormFields(${subItem.id})">
                                                            <p class="text-xs font-medium text-gray-900 dark:text-white">
                                                                ${itemName}
                                                            </p>
                                                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                                                                ${createdAt}
                                                            </p>
                                                        </div>
                                                        <button type="button" 
                                                            onclick="event.stopPropagation(); confirmDeleteItem(${subItem.id}, '${itemName.replace(/'/g, "\\'")}')"
                                                            class="ml-2 p-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
                                                            title="Delete item">
                                                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                            </svg>
                                                        </button>
                                                    </div>
                                                </div>
                                            `;
                                        }).join('')}
                                    </div>
                                </div>
                            `;
                                sidebarList.append(groupHtml);
                            } else {
                                // Render regular item (no group_by)
                                const itemName = item.item_name || 'No Item Name';
                                const createdAt = new Date(item.created_at).toLocaleDateString('en-US', {
                                    month: 'short',
                                    day: 'numeric',
                                    year: 'numeric'
                                });
                                const isSelected = selectedFormId && item.id == selectedFormId;
                                const bgClass = isSelected ?
                                    'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700' :
                                    'bg-gray-50 dark:bg-gray-700';

                                const itemHtml = `
                                <div class="p-3 ${bgClass} rounded-lg border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors sidebar-item"
                                     data-form-id="${item.id}">
                                    <div class="flex items-start justify-between">
                                        <div class="flex-1 cursor-pointer" onclick="loadFormFields(${item.id})">
                                            <p class="text-sm font-medium text-gray-900 dark:text-white">
                                                ${itemName}
                                            </p>
                                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                                Created: ${createdAt}
                                            </p>
                                        </div>
                                        <button type="button" 
                                            onclick="event.stopPropagation(); confirmDeleteItem(${item.id}, '${itemName.replace(/'/g, "\\'")}')"
                                            class="ml-2 p-1.5 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
                                            title="Delete item">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            `;
                                sidebarList.append(itemHtml);
                            }
                        });
                },
                error: function() {
                    console.error('Failed to refresh sidebar');
                }
            });
        }

        function showSuccessMessage(message) {
            const successMsg = $(`
                <div class="mb-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200 px-4 py-3 rounded-lg">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="font-medium">${message}</span>
                    </div>
                </div>
            `);

            $('main').prepend(successMsg);

            setTimeout(function() {
                successMsg.fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        }

        function updateFormDetails() {
            const oldClientName = '{{ $form->client_name }}';
            const oldProjectName = '{{ $form->project_name }}';
            const newClientName = $('#client_name').val().trim();
            const newProjectName = $('#project_name').val().trim();

            // Validate inputs
            if (!newClientName || !newProjectName) {
                alert('Please fill in both Client Name and Project Name.');
                return;
            }

            // Check if values have changed
            if (oldClientName === newClientName && oldProjectName === newProjectName) {
                alert('No changes detected. Client Name and Project Name are the same as before.');
                return;
            }

            // Confirm update
            if (!confirm(
                    `Are you sure you want to update all forms with client "${oldClientName}" and project "${oldProjectName}" to client "${newClientName}" and project "${newProjectName}"?`
                )) {
                return;
            }

            // Show loading state
            const updateBtn = $('#updateFormDetailsBtn');
            const originalText = updateBtn.html();
            updateBtn.prop('disabled', true).html(`
                <svg class="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Updating...
            `);

            // Make AJAX request
            $.ajax({
                url: '{{ route('forms.update-details') }}',
                method: 'POST',
                data: {
                    old_client_name: oldClientName,
                    old_project_name: oldProjectName,
                    new_client_name: newClientName,
                    new_project_name: newProjectName
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                success: function(response) {
                    updateBtn.prop('disabled', false).html(originalText);

                    // Show success message
                    showSuccessMessage(response.message || 'Forms updated successfully!');

                    // Refresh sidebar to reflect updated names
                    refreshSidebar();
                },
                error: function(xhr) {
                    updateBtn.prop('disabled', false).html(originalText);

                    let errorMessage = 'An error occurred while updating forms. Please try again.';

                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error;
                    } else if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }

                    alert(errorMessage);
                    console.error('Error updating forms:', xhr);
                }
            });
        }

        function loadSidebarItemsForDuplicate() {
            const clientName = $('#client_name').val();
            const projectName = $('#project_name').val();

            if (!clientName || !projectName) {
                alert('Please fill in Client Name and Project Name first');
                $('#duplicateCheckbox').prop('checked', false);
                $('#duplicateDropdownContainer').addClass('hidden');
                return;
            }

            const select = $('#duplicateItemSelect');
            select.html('<option value="">Loading items...</option>');

            $.ajax({
                url: '{{ route('api.sidebar-items') }}',
                method: 'GET',
                data: {
                    client_name: clientName,
                    project_name: projectName
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json'
                },
                success: function(items) {
                    select.html('<option value="">-- Select an item --</option>');

                    if (items.length === 0) {
                        select.html('<option value="">No items available</option>');
                        return;
                    }

                    // Flatten the items array to handle both grouped and ungrouped items
                    const flattenedItems = [];
                    items.forEach(function(item) {
                        if (item.is_group && item.items) {
                            // If it's a group, add all items from the group
                            item.items.forEach(function(groupItem) {
                                flattenedItems.push(groupItem);
                            });
                        } else if (item.id && item.item_name) {
                            // If it's a regular item, add it directly
                            flattenedItems.push(item);
                        }
                    });

                    if (flattenedItems.length === 0) {
                        select.html('<option value="">No items available</option>');
                        return;
                    }

                    flattenedItems.forEach(function(item) {
                        const itemName = item.item_name || 'No Item Name';
                        const option = $('<option></option>')
                            .attr('value', item.id)
                            .text(itemName);
                        select.append(option);
                    });
                },
                error: function() {
                    select.html('<option value="">Error loading items</option>');
                    console.error('Failed to load sidebar items for duplicate');
                }
            });
        }

        function duplicateItemFields(formId) {
            // Show loading state
            const duplicateButton = $('#duplicateButton');
            const originalText = duplicateButton.text();
            duplicateButton.prop('disabled', true).text('Loading...');

            $.ajax({
                url: `/api/forms/${formId}/fields`,
                method: 'GET',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    // Populate item name, unit, rate, and group_by
                    $('#fields_item_name').val(response.item_name || '');
                    $('#fields_unit').val(response.unit || '');
                    $('#fields_rate').val(response.rate || '');
                    $('#fields_group_by').val(response.group_by || '');

                    // Remove field IDs from duplicated fields so they're treated as new fields
                    const duplicatedResponse = {
                        form_id: null,
                        item_name: response.item_name,
                        unit: response.unit,
                        fields: response.fields.map(function(field) {
                            return {
                                id: null, // Remove ID so it's treated as a new field
                                index: field.index,
                                description: field.description || '',
                                quantity: field.quantity || '',
                                length: field.length || '',
                                width: field.width || '',
                                height: field.height || '',
                                product: field.product || ''
                            };
                        })
                    };

                    // Render the fields table with duplicated data (without IDs)
                    renderFieldsTable(duplicatedResponse);

                    duplicateButton.prop('disabled', false).text(originalText);

                    // Show success message
                    showSuccessMessage('Fields duplicated successfully!');
                },
                error: function(xhr) {
                    duplicateButton.prop('disabled', false).text(originalText);
                    alert('Failed to load fields from selected item. Please try again.');
                    console.error('Error loading form fields:', xhr);
                }
            });
        }

        function addFieldRow() {
            if (!currentFormId && $('#is_new_item').val() !== '1') {
                alert('Please select an item first or click "Add Item"');
                return;
            }

            const tbody = document.getElementById('fieldsTableBody');
            const currentRowCount = tbody.querySelectorAll('tr').length;
            const newIndex = currentRowCount;
            const row = document.createElement('tr');
            row.className = 'field-row border-b border-gray-200 dark:border-gray-700';
            row.innerHTML = `
                <td class="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">${newIndex + 1}</td>
                <td class="px-4 py-3">
                    <textarea name="fields[${newIndex}][description]" 
                              rows="1"
                              placeholder="Enter description"
                              oninput="calculateProduct(this)"
                              class="field-description w-full min-w-[300px] px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white resize-none"></textarea>
                </td>
                <td class="px-4 py-3">
                    <input type="number" 
                           name="fields[${newIndex}][quantity]" 
                           step="1" 
                           placeholder="0"
                           oninput="calculateProduct(this)"
                           class="field-quantity w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                </td>
                <td class="px-4 py-3">
                    <input type="number" 
                           name="fields[${newIndex}][length]" 
                           step="0.01" 
                           min="0"
                           placeholder="0"
                           oninput="calculateProduct(this)"
                           class="field-length w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                </td>
                <td class="px-4 py-3">
                    <input type="number" 
                           name="fields[${newIndex}][width]" 
                           step="0.01" 
                           min="0"
                           placeholder="0"
                           oninput="calculateProduct(this)"
                           class="field-width w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                </td>
                <td class="px-4 py-3">
                    <input type="number" 
                           name="fields[${newIndex}][height]" 
                           step="0.01" 
                           min="0"
                           placeholder="0"
                           oninput="calculateProduct(this)"
                           class="field-height w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                </td>
                <td class="px-4 py-3">
                    <input type="number" 
                           name="fields[${newIndex}][product]" 
                           step="0.01"
                           placeholder="0"
                           readonly
                           class="field-product w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-600 text-gray-700 dark:text-gray-300 cursor-not-allowed">
                </td>
                <td class="px-4 py-3">
                    <button type="button" 
                            onclick="removeFieldRow(this)" 
                            class="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                    </button>
                </td>
            `;
            tbody.appendChild(row);
            updateRowNumbers();
        }

        function removeFieldRow(button) {
            const row = button.closest('tr');
            // Clear all inputs in the row
            row.querySelectorAll('input[type="number"], textarea').forEach(input => {
                input.value = '';
            });
            // If there's a hidden ID field, we'll keep the row but mark it for deletion
            const hiddenId = row.querySelector('input[type="hidden"][name*="[id]"]');
            if (hiddenId) {
                // Optionally, you could add a hidden delete flag here
            }
        }

        function updateRowNumbers() {
            const rows = document.querySelectorAll('#fieldsTableBody tr');
            rows.forEach((row, index) => {
                row.querySelector('td:first-child').textContent = index + 1;
            });
        }

        // Auto-resize textareas
        document.addEventListener('input', function(e) {
            if (e.target.tagName === 'TEXTAREA') {
                e.target.style.height = 'auto';
                e.target.style.height = e.target.scrollHeight + 'px';
            }
        });

        // Allow navigation and editing keys (backspace, delete, arrow keys, etc.)
        document.addEventListener('keydown', function(e) {
            if (e.target.type === 'number' && e.target.readOnly === false) {
                // Allow: backspace, delete, tab, escape, enter, arrow keys, home, end
                if (['Backspace', 'Delete', 'Tab', 'Escape', 'Enter', 'ArrowLeft', 'ArrowRight', 'ArrowUp',
                        'ArrowDown', 'Home', 'End'
                    ].includes(e.key) ||
                    // Allow: Ctrl+A, Ctrl+C, Ctrl+V, Ctrl+X
                    ((e.key === 'a' || e.key === 'c' || e.key === 'v' || e.key === 'x') && e.ctrlKey)) {
                    return;
                }
            }
        });

        // Ensure only numbers and "." can be entered in number inputs
        document.addEventListener('keypress', function(e) {
            if (e.target.type === 'number' && e.target.readOnly === false) {
                // Allow decimal point
                if (e.key === '.' || e.key === '-') {
                    // Prevent if there's already a decimal point in the value
                    if (e.target.value.includes('.')) {
                        e.preventDefault();
                    }
                    return;
                }
                // Allow numbers (0-9)
                if (e.key >= '0' && e.key <= '9') {
                    return;
                }
                // Prevent all other characters
                e.preventDefault();
            }
        });

        // Prevent non-numeric characters on paste
        document.addEventListener('paste', function(e) {
            if (e.target.type === 'number' && e.target.readOnly === false) {
                e.preventDefault();
                const paste = (e.clipboardData || window.clipboardData).getData('text');
                const numericValue = paste.replace(/[^0-9.]/g, '');
                e.target.value = numericValue;
                // Trigger input event to recalculate product if needed
                if (e.target.classList.contains('field-quantity') ||
                    e.target.classList.contains('field-length') ||
                    e.target.classList.contains('field-width') ||
                    e.target.classList.contains('field-height')) {
                    calculateProduct(e.target);
                }
            }
        });

        // Calculate product for existing rows on page load
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.field-quantity, .field-length, .field-width, .field-height').forEach(
                input => {
                    if (input.value) {
                        calculateProduct(input);
                    }
                });
        });

        // Duplicate group functionality
        let groupToDuplicate = null;

        function confirmDuplicateGroup(groupBy) {
            groupToDuplicate = groupBy;
            const modal = document.getElementById('duplicateGroupModal');
            document.getElementById('originalGroupNameDisplay').value = groupBy;
            document.getElementById('newGroupNameInput').value = '';
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            
            // Focus on input after modal is shown
            setTimeout(() => {
                document.getElementById('newGroupNameInput').focus();
            }, 100);
        }

        // Cancel duplicate group
        document.getElementById('cancelDuplicateGroup').addEventListener('click', function() {
            const modal = document.getElementById('duplicateGroupModal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            groupToDuplicate = null;
        });

        // Close modal on outside click
        document.getElementById('duplicateGroupModal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.add('hidden');
                this.classList.remove('flex');
                groupToDuplicate = null;
            }
        });

        // Handle Enter key in new group name input
        document.getElementById('newGroupNameInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                document.getElementById('confirmDuplicateGroup').click();
            }
        });

        // Confirm duplicate group
        document.getElementById('confirmDuplicateGroup').addEventListener('click', function() {
            if (!groupToDuplicate) {
                return;
            }

            const newGroupName = document.getElementById('newGroupNameInput').value.trim();

            if (!newGroupName) {
                alert('Please enter a new group name.');
                return;
            }

            const confirmBtn = this;
            const originalText = confirmBtn.textContent;
            confirmBtn.disabled = true;
            confirmBtn.textContent = 'Duplicating...';

            const clientName = $('#client_name').val();
            const projectName = $('#project_name').val();

            $.ajax({
                url: '{{ route('forms.duplicate-group') }}',
                method: 'POST',
                data: {
                    client_name: clientName,
                    project_name: projectName,
                    group_by: groupToDuplicate,
                    new_group_by: newGroupName,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                success: function(response) {
                    const modal = document.getElementById('duplicateGroupModal');
                    modal.classList.add('hidden');
                    modal.classList.remove('flex');

                    // Refresh sidebar to show new duplicated group
                    refreshSidebar();

                    // Show success message
                    showSuccessMessage(response.message || 'Group duplicated successfully!');

                    groupToDuplicate = null;
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = originalText;
                },
                error: function(xhr) {
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = originalText;

                    let errorMessage = 'Failed to duplicate group. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error;
                    } else if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }

                    alert(errorMessage);
                    console.error('Error duplicating group:', xhr);
                }
            });
        });

        // Delete item functionality
        let itemToDeleteId = null;

        function confirmDeleteItem(formId, itemName) {
            itemToDeleteId = formId;
            const modal = document.getElementById('deleteItemModal');
            const message = document.getElementById('deleteItemModalMessage');
            message.textContent =
                `Are you sure you want to delete the item "${itemName}"? This action cannot be undone and all associated fields will be deleted.`;

            modal.classList.remove('hidden');
            modal.classList.add('flex');
            setTimeout(() => {
                modal.querySelector('div').classList.add('scale-100');
            }, 10);
        }

        // Cancel delete item
        document.getElementById('cancelDeleteItem').addEventListener('click', function() {
            const modal = document.getElementById('deleteItemModal');
            modal.querySelector('div').classList.remove('scale-100');
            setTimeout(() => {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
                itemToDeleteId = null;
            }, 200);
        });

        // Close modal on outside click
        document.getElementById('deleteItemModal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.querySelector('div').classList.remove('scale-100');
                setTimeout(() => {
                    this.classList.add('hidden');
                    this.classList.remove('flex');
                    itemToDeleteId = null;
                }, 200);
            }
        });

        // Confirm delete item
        document.getElementById('confirmDeleteItem').addEventListener('click', function() {
            if (!itemToDeleteId) {
                return;
            }

            const confirmBtn = this;
            const originalText = confirmBtn.textContent;
            confirmBtn.disabled = true;
            confirmBtn.textContent = 'Deleting...';

            $.ajax({
                url: `/forms/${itemToDeleteId}`,
                method: 'POST',
                data: {
                    _method: 'DELETE',
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                success: function(response) {
                    const modal = document.getElementById('deleteItemModal');
                    modal.querySelector('div').classList.remove('scale-100');
                    setTimeout(() => {
                        modal.classList.add('hidden');
                        modal.classList.remove('flex');
                    }, 200);

                    // Refresh sidebar
                    refreshSidebar();

                    // If the deleted item was currently being edited, clear the form
                    if (currentFormId === itemToDeleteId) {
                        currentFormId = null;
                        $('#messageSection').removeClass('hidden');
                        $('#fieldsSection').addClass('hidden');
                        $('#addRowBtn').addClass('hidden');
                        $('#updateFormBtn').addClass('hidden');
                        $('#exportDropdown').addClass('hidden');
                        $('#duplicateSection').addClass('hidden');
                    }

                    // Show success message
                    showSuccessMessage('Item deleted successfully!');

                    itemToDeleteId = null;
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = originalText;
                },
                error: function(xhr) {
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = originalText;

                    let errorMessage = 'Failed to delete item. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error;
                    } else if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }

                    alert(errorMessage);
                    console.error('Error deleting item:', xhr);
                }
            });
        });
    </script>
</body>

</html>
